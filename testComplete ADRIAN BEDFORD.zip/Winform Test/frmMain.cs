﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Winform_Test
{
    public partial class frmMain : Form
    {
        private List<Person> _people;

        public frmMain()
        {
            InitializeComponent();
            PopulateTestData(); //Insert test data into object list

            DataTable dtPeople = convertDataTable(_people); 
            dataGridView1.DataSource = dtPeople; //Initialise data grid with all people in list
        }


        private void PopulateTestData()
        {
            _people = new List<Person>();
            _people.Add(new Person { FirstName = "Jane", LastName = "Doe" });
            _people.Add(new Person { FirstName = "John", LastName = "Citizen" });
            _people.Add(new Person { FirstName = "Jack", LastName = "Johnson" });
            _people.Add(new Person { FirstName = "Alex", LastName = "Wilbers" });
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dtPeople = convertDataTable(_people);
            DataView dv = new DataView(dtPeople);

            dv.RowFilter = string.Format("FirstName like '%{0}%' or LastName like '%{0}%'", textBox1.Text); //Allows search queries to be fulfilled with either first or last name
            dataGridView1.DataSource = dv.ToTable(); //Updates grid view to show filtered results

        }

        private DataTable convertDataTable<T>(List<T> items) //Converts List of objects to a datatable
        {
            DataTable dt = new DataTable(typeof(T).Name);

            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance); //Returns properties (column headers) of Person object)

            foreach (PropertyInfo prop in Props) //Creates relevant column headers for datatable
            {
                dt.Columns.Add(prop.Name);
            }

            foreach (T item in items) //Fills row values with each objects specific data
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dt.Rows.Add(values);
            }

            return dt;
        }
    }
}
